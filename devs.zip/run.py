import os
os.system('python main.py;while :; do python main.py; sleep 1s; done')
